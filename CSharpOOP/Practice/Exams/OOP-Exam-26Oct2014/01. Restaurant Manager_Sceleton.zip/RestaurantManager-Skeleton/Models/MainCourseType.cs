﻿namespace RestaurantManager.Models
{
    public enum MainCourseType
    {
        Soup,
        Entree,
        Pasta,
        Side,
        Meat,
        Other
    }
}
