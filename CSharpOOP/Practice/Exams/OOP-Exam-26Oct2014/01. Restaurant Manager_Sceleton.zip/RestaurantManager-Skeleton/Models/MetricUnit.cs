﻿namespace RestaurantManager.Models
{
    public enum MetricUnit
    {
        Grams,
        Milliliters
    }
}
