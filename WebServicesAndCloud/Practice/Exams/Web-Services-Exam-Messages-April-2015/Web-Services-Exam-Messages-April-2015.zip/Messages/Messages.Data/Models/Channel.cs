﻿namespace Messages.Data.Models
{
    public class Channel
    {
        public int Id { get; set; }

        // TODO
    }
}
