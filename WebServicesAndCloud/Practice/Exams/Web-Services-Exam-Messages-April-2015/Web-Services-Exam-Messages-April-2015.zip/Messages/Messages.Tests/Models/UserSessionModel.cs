﻿namespace Messages.Tests.Models
{
    public class UserSessionModel
    {
        public string UserName { get; set; }
        
        public string Access_Token { get; set; }
    }
}
